node -v
v22.12.0

npm -v
10.9.0

# new project
npm create vite@latest flood-viz -- --template vue-ts
cd flood-viz


npm i vue-router pinia axios leaflet chart.js vue-chartjs

npm i -D tailwindcss postcss autoprefixer
npx tailwindcss init -p




一、基于文档梳理的前端完整需求

地图总览（主界面）

可对比并可视化基线（未淹水）与淹水情景的出行时间（私家车 & 公交），支持切换情景与出行方式；成果以道路分段着色表示延时分钟数，并可点击查看分段的基线、淹水、延时等指标。

支持显示反复受淹影响且延时最高的道路分段（热点/高延时段）。

支持显示**受影响可能性最高的公交线路（或路段）**覆盖层。

支持显示**关键性（criticality）**最高的道路分段（例如介数中心性高的段），并提供可切换的度量（如 betweenness）。

默认关注工作日 7:00–9:00早高峰（无需时序动画，但需在 UI 中告知/约束）。

图层与交互

左侧控制面板：

出行方式（Car / Public Transport）

情景（Worst-case / Historical / Baseline 等）

图层开关：延时、受淹道路、关键性、公交影响

结果 TopN 表（如：Top 10 延时分段 / Top 10 关键分段 / Top 10 受影响公交）

地图要素交互：鼠标悬停/点击弹出详细信息（分段 ID、延时、关键性等级、公交线路列表等）。

图例（延时分级配色、关键性线宽/颜色标注）。

数据接口（前端消费）

统一走 REST 风格接口，返回 GeoJSON / JSON：

/api/delay?mode=car|pt&scenario=...&agg=segment&limit=1000 返回分段延时（properties: segment_id, baseline_min, flooded_min, delay_min 等）。

/api/flooded_roads?scenario=... 返回受淹道路（LineString/FeatureCollection）。

/api/criticality?metric=betweenness 返回分段关键性（properties: segment_id, tier 等）。

/api/bus_impacts?scenario=... 返回受影响公交（properties: service_id, segments 等）。
（前端以 Axios/Fetch 获取后直接渲染地图；此接口设计与文档“前后端集成、返回 GeoJSON/JSON 动态渲染”的描述一致。）

以上交互与可视化均与文档“构建交互式网站、对比基线与淹水、识别受影响道路与公交、识别关键道路并在前端展示”的目标一致。


依赖与配置

如果你已创建 Vite+Vue+TS 项目，可直接补充/覆盖下列文件。

1) package.json









下面把你这个前端的运行机理、页面交互流程和运行后你会看到的结果一次性讲清楚（基于我们现在的代码结构：Vue3 + Vite + TypeScript + Pinia + Leaflet + Tailwind，数据走 public/mock/*.json）：

整体结构与数据流

状态中心（Pinia）：store/app.ts 里保存 3 类状态

scenario: 'baseline' | 'worst_case'（场景）

mode: 'car' | 'bus' | 'walk'（出行方式）

layers: { delay: boolean; flooded: boolean; criticality: boolean }（三类图层开关）

控制面板（ControlsPanel.vue）：左侧表单。你在这里选场景/出行方式、勾选图层，点击「Apply」后把参数同步进 store。

地图画布（MapCanvas.vue）：右侧 Leaflet 地图。它监听 store 的变化并调用 renderLayers() 重新绘图：

先把旧图层（延时/淹水/关键性）移除

按开关逐一加载对应的 GeoJSON（来自 public/mock/）

用不同的样式函数渲染，并绑定弹窗

数据来源（/public/mock）

delay_segments.json：道路分段 + 各模式在不同场景的耗时（或用于计算延时的参数）

flooded_roads.json：被淹的道路折线

criticality.json：关键路段（含 tier H/M/L 或权重）

地图如何渲染

底图：OpenStreetMap 瓦片，preferCanvas: true，默认居中在新加坡（[1.3521,103.8198]，缩放 11）。

延时图层（Delay Heat）

从 delay_segments.json 读取分段（LineString）。

依据 当前 scenario + mode 计算 delay_min（延时分钟）。

用一套分段色带上色（colorByDelay），延时越大越深。

绑定弹窗：显示 segment_id / baseline_min / flooded_min / delay_min。

淹水路段（Flooded Roads）

从 flooded_roads.json 读取折线。

统一蓝色虚线（例：#0077b6 + dashArray: '4,3'），只做示意。

关键路段（Criticality）

从 criticality.json 读取折线。

线宽跟 tier 或 weight 相关：H 粗、M 中、L 细（widthByTier）。

颜色偏灰（表达“结构重要性”，不跟延时混色）。

交互流程（你操作会发生什么）

npm run dev 打开浏览器（默认 http://localhost:5173/）。
页面是左右布局：左边面板、右边地图（OSM 底图）。

在左侧 Scenario 选择：

Baseline：正常场景

Worst Case：极端/最差场景

在 Travel Mode 选择出行方式：Car / Bus / Walk。

在 Layers 勾选你要看的图层：

Delay Heat（延时热度）

Flooded Roads（淹水路段）

Criticality（关键性）

点击 Apply：

面板把这三个字段写入 Pinia store

地图组件收到变化 → renderLayers()：

清除旧图层

读取相应 mock JSON → 计算样式 → 重新画在地图上

在地图上点击线段：看到弹窗（尤其是延时层会显示基线/淹水/延时分钟）。

反复切换：任何一次 Apply 都会刷新对应图层，让你对比不同场景/模式的影响。

你会看到的视觉结果

默认：OSM 底图 + 你上次保留的图层（或第一次 Apply 后的图层）。

勾选 Delay Heat：城市里出现若干红/橘色道路段，颜色深浅表示延时大小；Worst Case 通常会整体更“红”。

勾选 Flooded Roads：若干蓝色虚线道路覆盖在底图上，代表易淹或已淹路段。

勾选 Criticality：若干灰黑色线段，线越粗表示越关键。

弹窗：鼠标点到延时段落，会弹出延时详情（便于诊断某一段为什么“拖慢”）。

关键实现点（便于你理解或扩展）

强类型参数

Scenario = 'baseline' | 'worst_case'、Mode = 'car' | 'bus' | 'walk'、Layers 三开关。

控制面板通过 reactive 克隆一份本地状态，点 Apply 再写回 store，避免改到 store 的同一引用。

Leaflet + TS 的样式签名

L.geoJSON 的 style 在 TS 类型里签名是 (feature?: Feature) => PathOptions，所以我们写成：

style: (feature) => {
  const p = (feature && feature.properties) || {}
  return { /* PathOptions */ }
}


这样就满足“feature 可能为 undefined”的签名要求。

静态文件走 /public

fetch('/mock/xxx.json') 直接从 public/mock 读取，无 CORS 问题、无后端依赖。

性能与体验

preferCanvas: true 对大量矢量更友好；

每次只在需要时加载对应图层，且先移除旧层，避免叠加重复。

扩展位（之后你可以加）

给延时层加一个小型图例（色带与阈值）；

在加载时显示一个loading（例如在 store 里加 isLoading）；

给 Criticality 用 weight 连续映射而非 H/M/L 离散；

根据当前数据的 bbox 自动 map.fitBounds(...)。

总之，这个页面的原理就是：“左侧控制 → 写入全局状态 → 右侧地图 watch 状态 → 读取 mock → 样式化渲染”。运行后，你会在地图上看到随场景/模式变化而颜色（延时）和线宽（关键性）发生变化的道路网络；点击每一段，还能看到详细指标弹窗。