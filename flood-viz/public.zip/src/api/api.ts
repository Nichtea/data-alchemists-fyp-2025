// src/api/api.ts
import type {
    GeoJsonObject,
    FeatureCollection,
    Feature,
    LineString,
    Point,
  } from 'geojson'
  
  const MOCK = {
    DELAY: '/mock/delay_segments.json',
    FLOOD: '/mock/flooded_roads.json',
    CRIT:  '/mock/criticality.json',
  } as const
  
  async function loadJson<T = any>(url: string): Promise<T> {
    const res = await fetch(url)
    if (!res.ok) {
      throw new Error(`Failed to load ${url}: ${res.status} ${res.statusText}`)
    }
    return res.json()
  }
  
  function toFC(features: any[]): FeatureCollection {
    return { type: 'FeatureCollection', features } as FeatureCollection
  }
  
  /** --- Delay (路段耗时) --- */
  type DelayProps = {
    segment_id: number
    baseline_min: number
    flooded_min: number
    delay_min: number
    // 下面是我们在前端动态补充的字段
    delay_adj?: number
    delay_pct?: number
    delay_bucket?: string
    scenario?: string
    mode?: string
  }
  
  export async function getDelay(
    mode: 'car' | 'bus' | 'walk',
    scenario: 'baseline' | 'worst_case',
    agg: 'segment' | 'node',
    limit = 1000
  ): Promise<{ data: GeoJsonObject }> {
    const raw = await loadJson<FeatureCollection<LineString, DelayProps>>(MOCK.DELAY)
  
    const modeFactor = { car: 1.0, bus: 1.15, walk: 0.6 } as const
    const scenFactor = { baseline: 1.0, worst_case: 1.6 } as const
    const mf = modeFactor[mode] ?? 1.0
    const sf = scenFactor[scenario] ?? 1.0
  
    const features = raw.features.slice(0, limit).map((f) => {
      const p = { ...(f.properties || ({} as DelayProps)) }
      const delayAdj = (p.delay_min ?? 0) * mf * sf
      const delayPct = p.baseline_min ? delayAdj / p.baseline_min : 0
      const bucket =
        delayAdj >= 15 ? '15+' :
        delayAdj >= 10 ? '10-15' :
        delayAdj >=  6 ? '6-10'  :
        delayAdj >=  3 ? '3-6'   :
        delayAdj >   0 ? '0-3'   : '0'
  
      const props: DelayProps = {
        ...p,
        delay_adj: +delayAdj.toFixed(2),
        delay_pct: +delayPct.toFixed(4),
        delay_bucket: bucket,
        scenario,
        mode,
      }
  
      if (agg === 'segment') {
        return { ...f, properties: props } as Feature<LineString, DelayProps>
      } else {
        // 取线段中点作为 node 聚合的示例
        const coords = f.geometry.coordinates
        const mid = coords[Math.floor(coords.length / 2)]
        const point: Feature<Point, DelayProps> = {
          type: 'Feature',
          properties: props,
          geometry: { type: 'Point', coordinates: mid },
        }
        return point as any
      }
    })
  
    return { data: toFC(features) }
  }
  
  /** --- Flooded Roads (淹水路段) --- */
  type FloodProps = {
    name?: string
    depth_m?: number
    // 动态增强
    risk?: 'H' | 'M' | 'L' | 'N'
  }
  
  export async function getFloodedRoads(
    scenario: 'baseline' | 'worst_case'
  ): Promise<{ data: GeoJsonObject }> {
    const raw = await loadJson<FeatureCollection<LineString, FloodProps>>(MOCK.FLOOD)
  
    // worst_case 略微放大淹水深度，做前端情景演示
    const sFactor = scenario === 'worst_case' ? 1.3 : 1.0
  
    const features = raw.features.map((f) => {
      const depth = ((f.properties?.depth_m ?? 0) * sFactor)
      const risk: FloodProps['risk'] =
        depth >= 0.5 ? 'H' : depth >= 0.25 ? 'M' : depth > 0 ? 'L' : 'N'
      return {
        ...f,
        properties: { ...(f.properties || {}), depth_m: +depth.toFixed(2), risk },
      }
    })
  
    return { data: toFC(features) }
  }
  
  /** --- Criticality (关键路段) --- */
  type CritProps = {
    segment_id?: number
    tier?: 'H' | 'M' | 'L'
    score?: number
    // 动态增强
    weight?: number
    metric?: 'betweenness' | 'closeness'
  }
  
  export async function getCriticality(
    metric: 'betweenness' | 'closeness'
  ): Promise<{ data: GeoJsonObject }> {
    const raw = await loadJson<FeatureCollection<LineString, CritProps>>(MOCK.CRIT)
  
    const weightByTier: Record<NonNullable<CritProps['tier']>, number> = {
      H: 5,
      M: 3,
      L: 2,
    }
  
    const features = raw.features.map((f) => {
      const tier = (f.properties?.tier ?? 'L') as NonNullable<CritProps['tier']>
      const weight = weightByTier[tier] ?? 2
      return {
        ...f,
        properties: { ...(f.properties || {}), tier, weight, metric },
      }
    })
  
    return { data: toFC(features) }
  }
  