// src/api/types.ts
export type Scenario = 'baseline'|'worst_case';
export type Mode = 'car'|'bus';

export interface DelayFeatureProps {
  id: string;
  segment_id: string;
  baseline_min: number;
  flooded_min: number;
  delay_min: number;
  rank?: number;
}
export interface GeoJSON<T=any> { type:'FeatureCollection'; features: Array<{type:'Feature'; geometry:any; properties:T}>; }

