// src/store/app.ts
import { defineStore } from 'pinia'

export type Scenario = 'baseline' | 'worst_case'
export type Mode = 'car' | 'bus' | 'walk'
export type Layers = {
  delay: boolean
  flooded: boolean
  criticality: boolean
}

export const useAppStore = defineStore('app', {
  state: () => ({
    scenario: 'baseline' as Scenario,
    mode: 'car' as Mode,
    layers: {
      delay: true,
      flooded: true,
      criticality: false,
    } as Layers,
  }),
  actions: {
    setScenario(s: Scenario) {
      this.scenario = s
    },
    setMode(m: Mode) {
      this.mode = m
    },
    setLayerVisible<K extends keyof Layers>(key: K, on: boolean) {
      this.layers[key] = on
    },
    toggleLayer<K extends keyof Layers>(key: K) {
      this.layers[key] = !this.layers[key]
    },
  },
})
