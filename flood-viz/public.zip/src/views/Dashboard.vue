<script setup lang="ts">
import MapCanvas from '../components/MapCanvas.vue';
import ControlsPanel from '../components/ControlsPanel.vue';
</script>

<template>
  <div class="grid grid-cols-12 h-screen">
    <aside class="col-span-3 border-r overflow-auto">
      <ControlsPanel />
      <!-- 这里可继续放指标卡、表格组件 -->
    </aside>
    <main class="col-span-9">
      <MapCanvas />
    </main>
  </div>
</template>
