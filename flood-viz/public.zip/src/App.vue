
<script setup lang="ts">
import ControlsPanel from '@/components/ControlsPanel.vue'
import MapCanvas from '@/components/MapCanvas.vue'
</script>

<template>
  <div class="w-screen h-screen grid grid-cols-12">
    <aside class="col-span-3 md:col-span-3 lg:col-span-3 border-r border-gray-200 p-4">
      <ControlsPanel />
    </aside>
    <main class="col-span-9 md:col-span-9 lg:col-span-9">
      <MapCanvas />
    </main>
  </div>
</template>

<style scoped>
</style>
