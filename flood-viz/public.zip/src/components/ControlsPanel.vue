<script setup lang="ts">
import { reactive } from 'vue'
import { useAppStore, type Scenario, type Mode, type Layers } from '@/store/app'

const store = useAppStore()

// 明确声明本地表单的类型，避免 v-model 与 store 类型不一致
const local = reactive<{ scenario: Scenario; mode: Mode; layers: Layers }>({
  scenario: store.scenario,
  mode: store.mode,
  layers: { ...store.layers },
})

function onApply(): void {
  // 同步场景/出行方式
  store.setScenario(local.scenario)
  store.setMode(local.mode)

  // 强类型 entries，避免 k 变成 any
  const entries = Object.entries(local.layers) as Array<[keyof Layers, boolean]>
  for (const [k, v] of entries) {
    store.setLayerVisible(k, v)
  }
}
</script>

<template>
  <div class="space-y-6 text-sm">
    <div>
      <h3 class="font-semibold mb-2">Scenario</h3>
      <div class="space-y-1">
        <label class="flex items-center gap-2">
          <input type="radio" name="scenario" value="baseline" v-model="local.scenario" />
          <span>Baseline</span>
        </label>
        <label class="flex items-center gap-2">
          <input type="radio" name="scenario" value="worst_case" v-model="local.scenario" />
          <span>Worst Case</span>
        </label>
      </div>
    </div>

    <div>
      <h3 class="font-semibold mb-2">Travel Mode</h3>
      <select class="border rounded px-2 py-1 w-full" v-model="local.mode">
        <option value="car">Car</option>
        <option value="bus">Bus</option>
        <option value="walk">Walk</option>
      </select>
    </div>

    <div>
      <h3 class="font-semibold mb-2">Layers</h3>
      <label class="flex items-center gap-2">
        <input type="checkbox" v-model="local.layers.delay" />
        <span>Delay Heat</span>
      </label>
      <label class="flex items-center gap-2">
        <input type="checkbox" v-model="local.layers.flooded" />
        <span>Flooded Roads</span>
      </label>
      <label class="flex items-center gap-2">
        <input type="checkbox" v-model="local.layers.criticality" />
        <span>Criticality</span>
      </label>
    </div>

    <button @click="onApply" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded px-3 py-1">
      Apply
    </button>
  </div>
</template>

<style scoped>
</style>
