<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import L from 'leaflet'
import type { Feature, Geometry, GeoJsonProperties } from 'geojson'
import { useAppStore } from '@/store/app'
import { getDelay, getFloodedRoads, getCriticality } from '@/api/api'

const mapEl = ref<HTMLDivElement | null>(null)
let map: L.Map
let delayLayer: L.GeoJSON | null = null
let floodLayer: L.GeoJSON | null = null
let critLayer: L.GeoJSON | null = null

const store = useAppStore()

// 颜色/宽度映射
function colorByDelay(d: number) {
  return d >= 15 ? '#7f0000' :
         d >= 10 ? '#b30000' :
         d >=  6 ? '#d7301f' :
         d >=  3 ? '#ef6548' :
         d >   0 ? '#fc8d59' : '#cccccc'
}
function widthByTier(t?: 'H' | 'M' | 'L') {
  return t === 'H' ? 5 : t === 'M' ? 3 : 2
}

async function renderLayers() {
  // 清理旧图层
  ;[delayLayer, floodLayer, critLayer].forEach((l) => l && l.remove())
  delayLayer = floodLayer = critLayer = null

  // 延时热力（线段）
  if (store.layers.delay) {
    const { data } = await getDelay(store.mode, store.scenario, 'segment', 1000)
    delayLayer = L.geoJSON(data as any, {
      // 关键：feature 参数是可选（与 Leaflet 类型签名一致）
      style: (feature?: Feature<Geometry, GeoJsonProperties>): L.PathOptions => {
        const p: any = feature?.properties ?? {}
        const delay = Number(p.delay_min ?? 0)
        return { color: colorByDelay(delay), weight: 3, opacity: 0.9 }
      },
      onEachFeature: (f: any, layer: L.Layer) => {
        const p = f.properties || {}
        const html = `
          <b>Segment ${p.segment_id ?? ''}</b><br/>
          Baseline: ${Number(p.baseline_min ?? 0).toFixed(1)} min<br/>
          Flooded : ${Number(p.flooded_min ?? 0).toFixed(1)} min<br/>
          Delay   : <b>${Number(p.delay_min ?? 0).toFixed(1)} min</b>
        `
        ;(layer as L.Path).bindPopup(html)
      },
    }).addTo(map)
  }

  // 淹水路段（虚线）
  if (store.layers.flooded) {
    const { data } = await getFloodedRoads(store.scenario)
    floodLayer = L.geoJSON(data as any, {
      style: { color: '#0077b6', weight: 2, opacity: 0.7, dashArray: '4,3' },
    }).addTo(map)
  }

  // 关键路段（宽度按 tier）
  if (store.layers.criticality) {
    const { data } = await getCriticality('betweenness')
    critLayer = L.geoJSON(data as any, {
      style: (feature?: Feature<Geometry, GeoJsonProperties>): L.PathOptions => {
        const p: any = feature?.properties ?? {}
        return { color: '#222', weight: Number(p.weight ?? widthByTier(p.tier)), opacity: 0.6 }
      },
    }).addTo(map)
  }
}

onMounted(async () => {
  map = L.map(mapEl.value!, { preferCanvas: true }).setView([1.3521, 103.8198], 11)
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap',
  }).addTo(map)
  await renderLayers()
})

// 监听场景、模式和图层开关
watch(
  () => [store.scenario, store.mode, store.layers.delay, store.layers.flooded, store.layers.criticality],
  () => { renderLayers() },
  { deep: true }
)
</script>

<template>
  <div ref="mapEl" class="w-full h-full"></div>
</template>

<style scoped>
div { height: 100%; }
</style>
